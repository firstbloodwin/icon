import plotly.graph_objects as go
import plotly.offline as pyo
import os

# 示例数据
user_data = {
    "User1": {
        "Software1": 2,
        "Software2": 3,
        "Software3": 5
    },
    "User2": {
        "Software1": 1,
        "Software2": 4,
        "Software3": 3
    },
    # ... 其他用户数据
}

# 假设您已经有了为每个用户生成的图表的HTML代码，这里我们用占位符表示
charts_html = {
    "User1": "<div>User1's chart HTML code here</div>",
    "User2": "<div>User2's chart HTML code here</div>",
    # ... 其他用户的图表HTML
}

html_content = f"""  
<!DOCTYPE html>  
<html>  
<head>  
    <title>User Charts</title>  
</head>  
<body>  
    <select id="user-select" onchange="loadChart()">  
        {''.join([f'<option value="{user}">{user}</option>' for user in user_data.keys()])}  
    </select>  
    <div id="chart-container"></div>  
  
    <script>  
        const charts = {{  
            {','.join([f'"{user}": `{charts_html[user]}`' for user in charts_html.keys()])}  
        }};  
  
        function loadChart() {{  
            const user = document.getElementById("user-select").value;  
            const container = document.getElementById("chart-container");  
            container.innerHTML = charts[user];  
        }}  
  
        document.addEventListener('DOMContentLoaded', function() {{  
            loadChart(); // 初始加载第一个用户的图表  
        }});  
    </script>  
</body>  
</html>  
"""

# 现在html_content包含了正确的HTML页面代码，您可以将其写入文件或进行其他处理

# 将HTML内容写入文件
with open("index.html", "w") as f:
    f.write(html_content)

print("HTML page has been created successfully!")