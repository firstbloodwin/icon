import pandas as pd

data = {
    'productname': 'ADA-AL00',
    'productversion': 'ADA-AL00 4.2.0.101',
    'usage_time': 64437678,
    'start_app': 60023498,
    'start_activity': 3475798437589
}
s = [data]

df = pd.DataFrame(s)

print(df)
print(type(df))
