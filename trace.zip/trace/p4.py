import plotly.graph_objects as go
import plotly.io as pio
import base64
import json

# 示例数据
user_data = {
    "User1": {
        "Software1": 2,
        "Software2": 3,
        "Software3": 5
    },
    "User2": {
        "Software1": 1,
        "Software2": 4,
        "Software3": 3
    },
    # 添加更多用户数据...
}

# 为每个用户生成图表并转换为图片数据URI
charts_images = {}
for user, data in user_data.items():
    fig = go.Figure(
        data=[go.Bar(x=list(data.keys()), y=list(data.values()), name=user)])
    fig.update_layout(title=f"Usage Time for {user}")
    # 将图表转换为图片数据URI
    img_bytes = pio.to_image(fig, format='png')
    img_str = base64.b64encode(img_bytes).decode('utf-8')
    img_data_uri = f'data:image/png;base64,{img_str}'
    charts_images[user] = img_data_uri

# 创建主HTML页面
html_content = f"""  
<!DOCTYPE html>  
<html>  
<head>  
    <title>User Charts</title>  
</head>  
<body>  
    <select id="user-select" onchange="loadChart()">  
        {''.join([f'<option value="{user}">{user}</option>' for user in user_data.keys()])}  
    </select>  
    <div id="chart-container">  
        <!-- 图表将在这里显示 -->  
    </div>  
  
    <script>  
        const charts = {  
            {','.join([f'"{user}": "{charts_images[user]}"' for user in charts_images.keys()])}  
        };  
  
        function loadChart() {  
            const user = document.getElementById("user-select").value;  
            const container = document.getElementById("chart-container");  
            // 创建一个img元素来显示图表图片  
            const img = document.createElement('img');  
            img.src = charts[user];  
            img.alt = 'Chart for ' + user;  
            // 清除现有内容并添加新图片  
            container.innerHTML = '';  
            container.appendChild(img);  
        }  
  
        // 初始加载第一个用户的图表  
        document.addEventListener('DOMContentLoaded', function() {  
            loadChart();  
        });  
    </script>  
</body>  
</html>  
"""

# 将HTML内容写入文件
with open("index.html", "w") as f:
    f.write(html_content)

print("HTML page has been created successfully!")