import plotly.graph_objects as go

# 示例数据
user_data = {
    "User1": {
        "Software1": 2,
        "Software2": 3,
        "Software3": 5
    },
    "User2": {
        "Software1": 1,
        "Software2": 4,
        "Software3": 3
    },
    # 添加更多用户数据...
}

# 为每个用户生成图表并保存为HTML
for user, data in user_data.items():
    fig = go.Figure(
        data=[go.Bar(x=list(data.keys()), y=list(data.values()), name=user)])
    fig.update_layout(title=f"Usage Time for {user}")
    fig.write_html(f"{user}.html")