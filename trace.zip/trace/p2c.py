# 创建一个包含下拉框和图表容器的HTML文件
html_content = f"""  
<!DOCTYPE html>  
<html>  
<head>  
    <title>User Charts</title>  
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>  
</head>  
<body>  
    <select id="user-select" onchange="loadChart()">  
        {''.join([f'<option value="{user}">{user}</option>' for user in user_data.keys()])}  
    </select>  
    <div id="chart-container" style="width:600px;height:400px;"></div>  
  
    <script>  
        function loadChart() {  
            const user = document.getElementById("user-select").value;  
            const container = document.getElementById("chart-container");  
            Plotly.newPlot(container, [], {}, {displayModeBar: false}).then(function(gd) {  
                // 加载并显示新图表  
                fetch(`{user}_chart.html`)  
                    .then(response => response.text())  
                    .then(html => {  
                        const parser = new DOMParser();  
                        const doc = parser.parseFromString(html, 'text/html');  
                        const script = doc.querySelector('script');  
                        if (script) {  
                            eval(script.innerHTML);  
                        }  
                        const plotDiv = doc.querySelector('.plotly-graph-div');  
                        if (plotDiv) {  
                            container.innerHTML = '';  
                            container.appendChild(plotDiv);  
                        }  
                    });  
            });  
        }  
    </script>  
</body>  
</html>  
"""

# 将HTML内容写入文件
with open("index.html", "w") as f:
    f.write(html_content)