import plotly.graph_objects as go
import plotly.utils
import os
import json

# 示例数据
user_data = {
    "User1": {
        "Software1": 2,
        "Software2": 3,
        "Software3": 5
    },
    "User2": {
        "Software1": 1,
        "Software2": 4,
        "Software3": 3
    },
    # 添加更多用户数据...
    "User8": {
        "Software1": 2,
        "Software2": 2,
        "Software3": 6
    }
}

# 为每个用户生成图表并保存为JSON（不是HTML，因为我们将直接在主HTML中加载它们）
charts = {}
for user, data in user_data.items():
    fig = go.Figure(
        data=[go.Bar(x=list(data.keys()), y=list(data.values()), name=user)])
    fig.update_layout(title=f"Usage Time for {user}")
    # 将图表转换为JSON
    chart_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    charts[user] = chart_json

# 创建一个包含下拉框和图表容器的HTML文件
html_content = f"""  
<!DOCTYPE html>  
<html>  
<head>  
    <title>User Charts</title>  
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>  
</head>  
<body>  
    <select id="user-select" onchange="loadChart()">  
        {''.join([f'<option value="{user}">{user}</option>' for user in user_data.keys()])}  
    </select>  
    <div id="chart-container" style="width:600px;height:400px;"></div>  
  
    <script>  
        // 存储所有图表的JSON数据  
        const charts = {{  
            {','.join([f'"{user}": {chart}' for user, chart in charts.items()])}  
        }};  
  
        function loadChart() {{  
            const user = document.getElementById("user-select").value;  
            const container = document.getElementById("chart-container");  
            Plotly.react(container, JSON.parse(charts[user]), {{}});  
        }}  
  
        // 初始加载第一个用户的图表  
        document.addEventListener('DOMContentLoaded', function() {{  
            loadChart(); // 这将触发onchange事件，加载第一个用户的图表  
            document.getElementById("user-select").dispatchEvent(new Event('change'));  
        }});  
    </script>  
</body>  
</html>  
"""

# 将HTML内容写入文件
with open("index.html", "w") as f:
    f.write(html_content)

print("HTML page has been created successfully!")