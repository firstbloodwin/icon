import tkinter as tk

from frames import TraceFrame, LoginFrame

root = tk.Tk()
root.title("test")

trace_frame = TraceFrame(root)
trace_frame.pack()

# login_frame = LoginFrame(root)
# login_frame.pack()

root.mainloop()
