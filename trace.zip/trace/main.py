import os
from jinja2 import Template

# 设定文件夹路径
folder_path = 'test'

# 获取文件夹中所有HTML文件的名称
html_files = [
    file for file in os.listdir(folder_path) if file.endswith('.html')
]

# 使用jinja2模板引擎生成HTML
template = Template("""  
<!DOCTYPE html>  
<html>  
<head>  
    <title>User HTML Viewer</title>  
    <script>  
        function showUserHTML(userName) {  
            var iframe = document.getElementById('userHTML');  
            iframe.src = 'test/' + userName + '.html';  
        }  
    </script>  
</head>  
<body>  
    <h2>Select a User:</h2>  
    <select onchange="showUserHTML(this.value)">  
        {% for file in html_files %}  
        <option value="{{ file[:-5] }}">{{ file[:-5] }}</option>  
        {% endfor %}  
    </select>  
    <iframe id="userHTML" style="width:100%; height:500px;"></iframe>  
</body>  
</html>  
""")

html_content = template.render(html_files=html_files)

# 将生成的HTML内容写入文件
with open('user_viewer.html', 'w') as file:
    file.write(html_content)

print("HTML file has been created successfully!")
