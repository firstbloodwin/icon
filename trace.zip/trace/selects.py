# 定义列表
dropdown_contents = ["Option 1", "Option 2", "Option 3", "Option 4"]

# 生成HTML内容
html_content = f"""  
<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<meta name="viewport" content="width=device-width, initial-scale=1.0">  
<title>Dropdown Example</title>  
</head>  
<body>  
  
<h2>Select an Option</h2>  
  
<select id="myDropdown">  
{' '.join([f'<option value="{option}">{option}</option>' for option in dropdown_contents])}  
</select>  
  
</body>  
</html>  
"""

# 写入HTML文件
with open("dropdown_example.html", "w") as file:
    file.write(html_content)

print("HTML file has been created with the dropdown.")